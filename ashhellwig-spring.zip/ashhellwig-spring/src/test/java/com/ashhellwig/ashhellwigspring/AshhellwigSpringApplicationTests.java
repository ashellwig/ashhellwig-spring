package com.ashhellwig.ashhellwigspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AshhellwigSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
